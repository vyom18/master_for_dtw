package com.example.myapplication;

import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

//@SuppressLint("SetTextI18n")
public class MainActivity extends AppCompatActivity {
    ServerSocket serverSocket;
    Thread Thread1 = null;
    TextView tvIP, tvPort;
    TextView tvMessages;
    EditText etMessage;
    Button btnSend;
    public static ArrayList<DataOutputStream> ls;
    public static String SERVER_IP = "";
    public static final int SERVER_PORT = 9654;
    String message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvIP = findViewById(R.id.tvIP);
        tvPort = findViewById(R.id.tvPort);
        tvMessages = findViewById(R.id.tvMessages);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);
        try {
            SERVER_IP = getLocalIpAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        ls=new ArrayList<DataOutputStream>();
        Thread1 = new Thread(new Thread1());
        Thread1.start();
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                message = etMessage.getText().toString().trim();
                if (!message.isEmpty()) {
                    new Thread(new Thread3(message,ls)).start();
                }
            }
        });
    }
    private String getLocalIpAddress() throws UnknownHostException {
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
       assert (wifiManager!=null);
      //  assertNull(message);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        int ipInt = wifiInfo.getIpAddress();
        return InetAddress.getByAddress(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(ipInt).array()).getHostAddress();
    }
    private DataOutputStream output;
    private DataInputStream input;
int k=0;

    class Thread1 implements Runnable {

        @Override
        public void run() {

            try {
                serverSocket = new ServerSocket(SERVER_PORT);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvMessages.setText("Not connected");
                        tvIP.setText("IP: " + SERVER_IP);
                        tvPort.setText("Port: " + String.valueOf(SERVER_PORT));
                    }
                });
                while (true) {
                    Socket socket;
                    try {
                        socket = serverSocket.accept();
                        k++;
                        if(socket!=null) {

                            output = new DataOutputStream(socket.getOutputStream());

                            ls.add(output);
                            output.writeUTF(String.valueOf(ls.size()));
                            output.flush();



                        new Thread(new Thread2(k,socket)).start();}
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }catch(IOException e){
                    e.printStackTrace();
                }

        }
    }
    private class Thread2 implements Runnable {
        int k;
        Socket socket;
        Thread2(int p,Socket s){
            k=p;
            socket=s;
        }
        @Override
        public void run() {
            try {
                input = new DataInputStream(socket.getInputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }

            while (true) {
                try {
                    final String message = input.readUTF();
                    if (message!= null)
                    {

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvMessages.setText("client"+k+":" + message + " ");
                            }
                        });
                    }
                   /* if(message==null)
                    {
                        Thread1 = new Thread(new Thread1());
                        Thread1.start();
                        return;
                    }*/
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    class Thread3 implements Runnable {
        private String message;
        ArrayList<DataOutputStream> list;
        Thread3(String message,ArrayList<DataOutputStream> gs) {
            this.message = message;list=gs;

        }
        @Override
        public void run() {

            try {

                for( DataOutputStream ds:ls) {
                    ds.writeUTF(message);
                    ds.flush();


                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvMessages.append("server: " + message + " ");
                        etMessage.setText("");
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }
}